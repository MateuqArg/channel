<?php if(Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <p class="mb-0"><i class="bi bi-check-circle-fill"></i> <?php echo e(Session::get('success')); ?></p>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>

          <input type="number" wire:model="uid" id="uid">
          <div class="mb-3">
            <div class="mb-3">
              <label for="company" class="form-label">Empresa</label>
              <input type="text" wire:model="company" id="company" class="form-control" aria-describedby="companyHelp">
            </div>
            <div class="mb-3">
              <label for="charge" class="form-label">Cargo</label>
              <input type="text" wire:model="charge" id="charge" class="form-control" aria-describedby="chargeHelp">
            </div>
            <div class="mb-3">
              <label for="country" class="form-label">País</label>
              <input type="text" wire:model="country" id="country" class="form-control" aria-describedby="countryHelp">
            </div>
            <div class="mb-3">
              <label for="state" class="form-label">Provincia</label>
              <input type="text" wire:model="state" id="state" class="form-control" aria-describedby="stateHelp">
            </div>
            <div class="mb-3">
              <label for="city" class="form-label">Ciudad</label>
              <input type="text" wire:model="city" id="city" class="form-control" aria-describedby="cityHelp">
            </div>
            <div class="mb-3 form-check">
              <label class="form-check-label" for="vip">¿Este asistente es de tipo VIP?</label>
              <input class="form-check-input" type="checkbox" wire:model="vip" id="vip" aria-describedby="vipHelp">
            </div>
          </div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/form.blade.php ENDPATH**/ ?>