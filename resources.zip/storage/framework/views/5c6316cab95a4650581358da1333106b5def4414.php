<a id="meet-btn<?php echo e($visitor->id); ?>"><i class="bi bi-people btn btn-outline-primary"></i></a>
<script>
  window.livewire.on('alert', function(){
    $('#edit<?php echo e($visitor->id); ?>').modal('hide');
    Swal.fire(
      '¡Eliminado!',
      'El asistente ha sido modificado',
      'success'
    )
  })

  $(document).on("click", "#meet-btn<?php echo e($visitor->id); ?>", function () {
    Swal.fire({
      title: '¿Estás seguro?',
      text: "Solicitaras una reunión con <?php echo e($forms[$visitor->form_id]['Nombre completo']); ?>",
      icon: 'info',
      showCancelButton: true,
      cancelButtonColor: '#d33',
      confirmButtonText: 'Confirmar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.Livewire.emit('meet', <?php echo e($visitor->id); ?>)
        Swal.fire(
          '¡Solo queda esperar!',
          'La reunión se ha solicitado correctamente',
          'success'
        )
      }
    })
  });
</script>
<?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/exhvisitor/actions.blade.php ENDPATH**/ ?>