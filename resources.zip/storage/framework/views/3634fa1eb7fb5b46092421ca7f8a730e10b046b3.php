<a id="edit-btn" data-bs-toggle="modal" data-id="<?php echo e($talk->id); ?>" data-bs-target="#edit<?php echo e($talk->id); ?>"><i class="bi bi-pencil btn btn-outline-primary"></i></a>
<a id="delete-btn" data-id="<?php echo e($talk->id); ?>"><i class="bi bi-trash btn btn-outline-danger"></i></a>
<div class="modal fade" wire:ignore.self id="edit<?php echo e($talk->id); ?>" tabindex="-1" aria-labelledby="createLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editLabel">Editar charla</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3" wire:ignore>
          <label for="events" class="form-label">Selecciona el evento relacionado a la charla</label>
          <select class="form-control" wire:model.defer="talk.event" id="events<?php echo e($talk->id); ?>">
              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($event->id); ?>"><?php echo e($event->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="mb-3" wire:ignore>
          <label for="exhibitors" class="form-label">Ahora selecciona el usuario que será expositor</label>
            <select class="form-control" wire:model.defer="talk.exhibitor" id="exhibitors<?php echo e($talk->id); ?>">
              <?php $__currentLoopData = $exhibitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($exhibitor->id); ?>"><?php echo e($exhibitor->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
          <label for="title" class="form-label">Titulo</label>
          <input type="text" wire:model="talk.title" id="title" class="form-control" aria-describedby="titleHelp">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-arrow-left"></i></button>
        <button wire:click="update(<?php echo e($talk->id); ?>)" class="btn btn-success"><i class="bi bi-send"></i> ENVIAR</button>
      </div>
    </div>
  </div>
</div>
<script>
  $(document).ready(function() {
    $('#events<?php echo e($talk->id); ?>').select2({theme: 'bootstrap-5', dropdownParent: $('#edit<?php echo e($talk->id); ?>')});
    $('#exhibitors<?php echo e($talk->id); ?>').select2({theme: 'bootstrap-5', dropdownParent: $('#edit<?php echo e($talk->id); ?>')});
  });

  $('#events<?php echo e($talk->id); ?>').on('change', function (e) {
        var data = $('#events<?php echo e($talk->id); ?>').select2("val");
        window.livewire.find('<?php echo e($_instance->id); ?>').set('talk.event', data);
  });

  $('#exhibitors<?php echo e($talk->id); ?>').on('change', function (e) {
        var data = $('#exhibitors<?php echo e($talk->id); ?>').select2("val");
        window.livewire.find('<?php echo e($_instance->id); ?>').set('talk.exhibitor', data);
  });

  $(document).on("click", "#edit-btn", function () {
      window.Livewire.emit('selected', $(this).data('id'))
  });
  
  $(document).on("click", "#delete-btn", function () {
    Swal.fire({
      title: '¿Estás seguro?',
      text: "¡No podras revertir esta acción!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, ¡eliminarla!',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.Livewire.emit('destroy', $(this).data('id'))
      }
    })
  });
</script>
<?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/talk/actions.blade.php ENDPATH**/ ?>