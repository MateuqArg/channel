<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <div class="row mt-4">
    <div class="col"></div>
    <div class="col align-self-center">
      <p>La impresión de la credencial debería haber sido enviada automáticamente, en caso de no ser así podés reintentar el proceso con el siguiente botón <a href="<?php echo e(route('organizer.visitor.print', ['custid' => $visitor->custid])); ?>">IMPRIMIR</a></p>
      <h4>Verificar datos personales</h4>
      <p>Nombre: <?php echo e($forms[$visitor->form_id]['Nombre completo']); ?> <br>
          Empresa: <?php echo e($forms[$visitor->form_id]['Empresa']); ?><br>
          Cargo: <?php echo e($forms[$visitor->form_id]['Cargo']); ?><br>
          <?php if($visitor->vip == true): ?>
            *Este usuario es VIP
          <?php endif; ?>
      </p>
      <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(300)->generate(route('organizer.visitor.track', ['custid' => $visitor->custid]))); ?> ">
    </div>
    <div class="col"></div>
  </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/organizer/visitor/scan.blade.php ENDPATH**/ ?>