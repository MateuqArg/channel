<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
          <a class="text-decoration-none" href="<?php echo e(route('visitor.inscription', ['custid' => $event->custid])); ?>">
            <div class="card shadow-sm">
              <div class="classes-card d-flex align-items-center" style="background-color: #949494;">
                  <h3 class="classes-card-text text-center mb-0"><?php echo e($event->title); ?></h3>
              </div>

              <div class="card-body">
                <p class="card-text subtitle">ID: <?php echo e($event->custid); ?></p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">Fecha: <?php echo e($event->date); ?></small>
                </div>
              </div>
            </div>
          </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/main/index.blade.php ENDPATH**/ ?>