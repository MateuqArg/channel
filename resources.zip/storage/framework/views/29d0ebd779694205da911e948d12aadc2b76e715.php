<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.exhibitornavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/jquery.flexdatalist.min.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('/js/jquery.flexdatalist.min.js')); ?>"></script>

<div class="container-fluid">
  <?php if(!$meetings->isEmpty()): ?>
  <div class="row">
    <a class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#meetings" href="">
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <p class="mb-0"><i class="bi bi-check-circle-fill"></i> Hay reuniones pendientes de aprobación</p>
    </div>
    </a>
  </div>
  <?php endif; ?>
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3">
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
          <a class="text-decoration-none" href="">
            <div class="card shadow-sm">
              <div class="classes-card d-flex align-items-center" style="background-color: #949494;">
                  <h3 class="classes-card-text text-center mb-0"><?php echo e($event->title); ?></h3>
              </div>

              <div class="card-body">
                <p class="card-text subtitle">ID: <?php echo e($event->custid); ?></p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">Fecha: <?php echo e($event->date); ?></small>
                </div>
              </div>
            </div>
          </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<a data-bs-toggle="modal" data-bs-target="#request" class="btn btn-success btn-create" href=""><i class="bi bi-plus-lg"></i></a>

<div class="modal fade" id="request" tabindex="-1" aria-labelledby="requestLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="requestLabel">Solicitar reunión</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <?php if(Session::has('successrequest')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <p class="mb-0"><i class="bi bi-check-circle-fill"></i> <?php echo e(Session::get('successrequest')); ?></p>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
        <form method="POST" action="<?php echo e(route('exhibitor.meeting.request')); ?>">
          <?php echo csrf_field(); ?>

          <div class="mb-3">
            <label for="select" class="form-label">Selecciona el evento para la reunión</label>
            <br>
            <input id="events" type='text' placeholder='Escribe el nombre' multiple='multiple' class='flexdatalist' name='events[]'>
            <br>
            <label for="select" class="form-label">Ahora selecciona el visitante</label>
            <br>
            <input id="visitors" type='text' placeholder='Escribe el nombre' multiple='multiple' class='flexdatalist' name='visitors[]'>
            <div id="titleHelp" class="form-text">We'll never share your email with anyone else.</div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-arrow-left"></i></button>
        <button type="submit" class="btn btn-success"><i class="bi bi-send"></i> ENVIAR</button>
      </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="meetings" tabindex="-1" aria-labelledby="meetingsLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="meetingsLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="accordion" id="accordionExample">
          <?php if(Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <p class="mb-0"><i class="bi bi-check-circle-fill"></i> <?php echo e(Session::get('success')); ?></p>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
          <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="accordion-item">
            <h2 class="accordion-header">
              <div class="row">
                <div class="col-9">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($meeting->custid); ?>" aria-expanded="true" aria-controls="<?php echo e($meeting->custid); ?>">
                    <?php echo e($meeting->visitor->name); ?> - <?php echo e($meeting->event->title); ?>

                  </button>
                </div>
                <div class="col-1">
                  <a class="btn btn-success" href="<?php echo e(route('exhibitor.meeting.accept', ['id' => $meeting->id])); ?>"><i class="bi bi-check-lg"></i></a>
                </div>
                <div class="col-1 ms-1">
                  <a class="btn btn-danger" href="<?php echo e(route('exhibitor.meeting.reject', ['id' => $meeting->id])); ?>"><i class="bi bi-x-lg"></i></a>
                </div>
              </div>
            </h2>
            <div id="<?php echo e($meeting->custid); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p class="mb-0">
                  <strong>Nombre:</strong> <?php echo e($forms[$visitor->form_id]['Nombre completo']); ?><br>
                  <strong>Email:</strong> <?php echo e($forms[$visitor->form_id]['Direccion de email']); ?><br>
                  <strong>Teléfono:</strong> <?php echo e($forms[$visitor->form_id]['Telefono']); ?><br>
                  <strong>Empresa:</strong> <?php echo e($forms[$visitor->form_id]['Empresa']); ?><br>
                  <strong>Cargo:</strong> <?php echo e($forms[$visitor->form_id]['Cargo']); ?><br>
                  <strong>Provincia:</strong> <?php echo e($forms[$visitor->form_id]['Provincia']); ?><br>
                  <strong>Ciudad:</strong> <?php echo e($forms[$visitor->form_id]['Localidad']); ?>

                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  var visitors = [
    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      { id: '<?php echo e($visitor->id); ?>',
      custid: '<?php echo e($visitor->custid); ?>',
      event: '<?php echo e($visitor->event->title); ?>',
      name: '<?php echo e($forms[$visitor->form_id]['Nombre completo']); ?>',
      },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ];

  var events = [
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      { id: '<?php echo e($event->id); ?>',
      custid: '<?php echo e($event->custid); ?>',
      title: '<?php echo e($event->title); ?>',
      },
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ];

  $('#events').flexdatalist({
    data: events,
    searchIn: ["title"],
    minLength: 0,
    valueProperty: 'id',
    // visibleProperties: ["name","custid","email"],
    noResultsText: 'No hay resultados',
  })

  $('#visitors').flexdatalist({
    data: visitors,
    searchIn: ["name","event"],
    minLength: 0,
    valueProperty: 'id',
    // visibleProperties: ["name","custid","email"],
    chainedRelatives: true,
    relatives: '#events',
    searchByWord: true,
    groupBy: 'event',
    noResultsText: 'No hay resultados',
  });

  // var visitors = [
  //   <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  //     { id: '<?php echo e($visitor->id); ?>',
  //     custid: '<?php echo e($visitor->custid); ?>',
  //     event: '<?php echo e($visitor->event->title); ?>',
  //     name: '<?php echo e($visitor->name); ?>',
  //     email: '<?php echo e($visitor->email); ?>',
  //     },
  //   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  // ];
  // // $('#events').on('select:flexdatalist', function(event, set, options) {
  // //   console.log($('#events').flexdatalist('value'))  
  // //         <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  // //         if (set.title == '<?php echo e($visitor->event->title); ?>') {
  // //           visitors.push({ id: '<?php echo e($visitor->id); ?>',
  // //           custid: '<?php echo e($visitor->custid); ?>',
  // //           event: '<?php echo e($visitor->event->title); ?>',
  // //           event_id: '<?php echo e($visitor->event->id); ?>',
  // //           name: '<?php echo e($visitor->name); ?>',
  // //           email: '<?php echo e($visitor->email); ?>',
  // //           })
  // //         }
  // //         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  // // });

  // // $('#events').on('after:flexdatalist.remove', function(event) {
  // //   visitors.forEach(function(visitor, index) {
  // //     if (!($('#events').flexdatalist('value').indexOf(visitor.event_id) > -1)) {
  // //       $('#visitors').flexdatalist('remove', 1)
  // //     }
  // //   });
  // // });
</script>
<script>
  <?php if(Session::has('success')): ?>
  $(document).ready(function(){
    $('#meetings').modal('show');
  });
  <?php endif; ?>
  <?php if(Session::has('successrequest')): ?>
  $(document).ready(function(){
    $('#request').modal('show');
  });
  <?php endif; ?>
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/exhibitor/events/index.blade.php ENDPATH**/ ?>