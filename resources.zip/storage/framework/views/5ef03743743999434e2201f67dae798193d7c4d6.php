
<?php $__env->startSection('content'); ?>
<?php if(\Auth::user()->hasRole('exhibitor')): ?>
<?php echo $__env->make('includes.auth.exhibitornavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(\Auth::user()->hasRole('organizer')): ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('includes.auth.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<div class="container">
    <div class="row row-cols-1 g-3 ms-5 me-5">
        <div class="col">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profiles')->html();
} elseif ($_instance->childHasBeenRendered('1yiKNew')) {
    $componentId = $_instance->getRenderedChildComponentId('1yiKNew');
    $componentTag = $_instance->getRenderedChildComponentTagName('1yiKNew');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1yiKNew');
} else {
    $response = \Livewire\Livewire::mount('profiles');
    $html = $response->html();
    $_instance->logRenderedChild('1yiKNew', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/main/profile.blade.php ENDPATH**/ ?>