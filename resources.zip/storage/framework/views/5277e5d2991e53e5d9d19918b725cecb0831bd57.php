<a id="edit-btn" data-bs-toggle="modal" data-id="<?php echo e($exhibitor->id); ?>" data-bs-target="#edit<?php echo e($exhibitor->id); ?>"><i class="bi bi-pencil btn btn-outline-primary"></i></a>
<a id="delete-btn" data-id="<?php echo e($exhibitor->id); ?>"><i class="bi bi-trash btn btn-outline-danger"></i></a>
<div class="modal fade" wire:ignore.self id="edit<?php echo e($exhibitor->id); ?>" tabindex="-1" aria-labelledby="createLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editLabel">Editar roles</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <div class="mb-3" wire:ignore>
          <p>ID público de todos los eventos</p>
          <select class="form-control" wire:model="exhibitor.role" id="roles<?php echo e($exhibitor->id); ?>" multiple="multiple">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(strlen($role->name) == 6): ?>
            <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-arrow-left"></i></button>
      <button wire:click="update(<?php echo e($exhibitor->id); ?>)" class="btn btn-success"><i class="bi bi-send"></i> ENVIAR</button>
    </div>
  </div>
</div>
<script>
  $(function () {
    $('#roles<?php echo e($exhibitor->id); ?>').select2({theme: 'bootstrap-5', dropdownParent: $('#edit<?php echo e($exhibitor->id); ?>')});
  });

  $('#roles<?php echo e($exhibitor->id); ?>').on('change', function (e) {
        var data = $('#roles<?php echo e($exhibitor->id); ?>').select2("val");
        window.livewire.find('<?php echo e($_instance->id); ?>').set('exhibitor.role', data);
  });

  $(document).on("click", "#edit-btn", function () {
      window.Livewire.emit('selected', $(this).data('id'))
  });
  
  $(document).on("click", "#delete-btn", function () {
    Swal.fire({
      title: '¿Estás seguro?',
      text: "¡No podras revertir esta acción!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, ¡eliminarla!',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        window.Livewire.emit('destroy', $(this).data('id'))
      }
    })
  });
</script><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/exhibitor/actions.blade.php ENDPATH**/ ?>