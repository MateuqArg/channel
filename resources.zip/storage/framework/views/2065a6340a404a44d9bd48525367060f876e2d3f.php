<div class="container-fluid">
  <div class="row g-3">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Acciones</th>
          <th scope="col">#</th>
          <th scope="col">Evento</th>
          <th scope="col">¿Presente?</th>
          <th scope="col">Empresa</th>
          <th scope="col">Cargo</th>
          <th scope="col">País</th>
          <th scope="col">Provincia</th>
          <th scope="col">Ciudad</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <?php echo $__env->make('livewire.actions', ['visitor' => $visitor], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </td>
          <td><?php echo e($visitor->custid); ?></td>
          <td><?php echo e($visitor->event->title); ?></td>
          <td><?php echo e($visitor->present ? "Si" : "No"); ?></td>
          <td><?php echo e($visitor->company); ?></td>
          <td><?php echo e($visitor->charge); ?></td>
          <td><?php echo e($visitor->country); ?></td>
          <td><?php echo e($visitor->state); ?></td>
          <td><?php echo e($visitor->city); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/visitor.blade.php ENDPATH**/ ?>