<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/jquery.flexdatalist.min.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('/js/jquery.flexdatalist.min.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-borderless/borderless.css">

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('visitors')->html();
} elseif ($_instance->childHasBeenRendered('Uhx62Ol')) {
    $componentId = $_instance->getRenderedChildComponentId('Uhx62Ol');
    $componentTag = $_instance->getRenderedChildComponentTagName('Uhx62Ol');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Uhx62Ol');
} else {
    $response = \Livewire\Livewire::mount('visitors');
    $html = $response->html();
    $_instance->logRenderedChild('Uhx62Ol', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/organizer/events/visitors.blade.php ENDPATH**/ ?>