<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
  <div class="row mt-4">
    <div class="col"></div>
    <div class="col align-self-center">
      <form method="GET" action="<?php echo e(route('organizer.visitor.store', ['id' => $visitor->id])); ?>">
        <div class="mb-3">
          <label for="talks" class="form-label">Seleccionar entre la lista de charlas</label>
          <select class="form-control" name="talk" id="talks">
            <?php $__currentLoopData = $talks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($talk->id); ?>"><?php echo e($talk->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <button class="btn btn-success w-100 mb-3">ENVIAR</button>
      </form>
      <h4>Datos personales</h4>
      <p>Nombre: <?php echo e($forms[$visitor->form_id]['Nombre completo']); ?> <br>
        Email: <?php echo e($forms[$visitor->form_id]['Direccion de email']); ?> <br>
        Teléfono: <?php echo e($forms[$visitor->form_id]['Telefono']); ?> <br>
        Empresa: <?php echo e($forms[$visitor->form_id]['Empresa']); ?><br>
        Cargo: <?php echo e($forms[$visitor->form_id]['Cargo']); ?><br>
        Provincia: <?php echo e($forms[$visitor->form_id]['Provincia']); ?><br>
        Ciudad: <?php echo e($forms[$visitor->form_id]['Localidad']); ?><br>
      </p>
    </div>
    <div class="col"></div>
  </div>
</div>





<script>
  $(document).ready(function() {
    $('#talks').select2({theme: 'bootstrap-5'});
  });

  <?php if(Session::has('alert')): ?>
  $(document).ready(function() {
    Swal.fire({
      title: '¡Genial!',
      html: 'El ingreso ha sido registrado correctamente.',
      icon: 'success',
      timer: 2000,
    })
  });
  <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/organizer/visitor/track.blade.php ENDPATH**/ ?>