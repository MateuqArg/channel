<?php $__env->startSection('content'); ?>
    <main class="form-signin">
      <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <img class="mb-4" src="https://getbootstrap.com/docs/5.1/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">

        <!-- Validation Errors -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <div class="form-floating mb-2">
          <input type="name" class="form-control" name="name" id="name" :value="old('name')" required autofocus>
          <label for="name">Nombre</label>
        </div>

        <div class="form-floating mb-2">
          <input type="email" class="form-control" name="email" id="email" :value="old('email')" required>
          <label for="email">Email</label>
        </div>

        <div class="form-floating mb-2">
          <input type="number" class="form-control" name="phone" id="phone" :value="old('phone')" required>
          <label for="phone">Teléfono</label>
        </div>

        <div class="form-floating mb-2">
          <input type="password" class="form-control" name="password" id="password" required autocomplete="new-password">
          <label for="password">Contraseña</label>
        </div>

        <div class="form-floating mb-2">
          <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" required>
          <label for="password_confirmation">Confirmar contraseña</label>
        </div>

        <div class="mb-3">
          <a href="<?php echo e(route('login')); ?>">¿Ya estás registrado?</a>
        </div>

        <button class="w-100 btn btn-lg btn-primary" type="submit">Crear cuenta</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2022 ChannelTalks</p>
        </form>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/auth/register.blade.php ENDPATH**/ ?>