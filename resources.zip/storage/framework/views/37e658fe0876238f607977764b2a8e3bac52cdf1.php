<div class="container-fluid">
  <div class="row">
    <div class="col d-flex gradient top-table">
      <div>
        <input type="text" wire:model="search" class="form-control" placeholder="Buscar por id o eventos">
      </div>
      <div class="ms-auto">
        <button wire:click="download" class="btn btn-outline-primary download-btn"><i class="bi bi-download"></i> DESCARGAR</button>
      </div>
    </div>
  </div>
  <div class="row g-3">
    <table class="table">
      <thead class="gradient">
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <th scope="col">Acciones</th>
          <?php endif; ?>
          <th scope="col">ID</th>
          <th scope="col">ID publico</th>
          <th scope="col">Nombre</th>
          <th scope="col">Eventos</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $exhibitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <td>
            <?php echo $__env->make('livewire.exhibitor.actions', ['exhibitor' => $exhibitor], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </td>
          <?php endif; ?>
          <td><?php echo e($exhibitor->id); ?></td>
          <td><?php echo e($exhibitor->custid); ?></td>
          <td><?php echo e($exhibitor->name); ?></td>
          <?php $__currentLoopData = $exhibitor->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(strlen($role) == 6): ?>
            <td><?php echo e($role); ?></td>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <?php if(!\Auth::user()->hasRole('staff')): ?>
  <?php echo $__env->make('livewire.exhibitor.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <script>
    window.livewire.on('alert', event => {
      $('#edit' + event.id).modal('hide');
      $('#create').modal('hide');
      Swal.fire({
        title: event.title,
        html: event.text,
        icon: event.type,
        timer: 2000,
      })
    })
  </script>
</div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/exhibitor/exhibitor.blade.php ENDPATH**/ ?>