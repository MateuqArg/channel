<div class="container-fluid">
  <div class="row">
    <div class="col d-flex gradient top-table">
      <div>
        <input type="text" wire:model="search" class="form-control" placeholder="Buscar por id, nombre o empresa">
      </div>
      <div class="ms-auto">
        <button wire:click="download" class="btn btn-outline-primary download-btn"><i class="bi bi-download"></i> DESCARGAR</button>
      </div>
    </div>
  </div>
  <div class="row g-3">
    <table class="table">
      <thead class="gradient">
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <th scope="col">Acciones</th>
          <?php endif; ?>
          <th scope="col">ID</th>
          <th scope="col">ID público</th>
          <th scope="col">Evento</th>
          <th scope="col">Nombre</th>
          <th scope="col">¿Presente?</th>
          <th scope="col">Email</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Empresa</th>
          <th scope="col">Cargo</th>
          <th scope="col">Provincia</th>
          <th scope="col">Ciudad</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <td>
            <?php echo $__env->make('livewire.visitor.actions', ['visitor' => $visitor], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </td>
          <?php endif; ?>
          <td><?php echo e($visitor->id); ?></td>
          <td><?php echo e($visitor->custid); ?></td>
          <td><?php echo e($visitor->event->title); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Nombre completo']); ?></td>
          <td><?php echo e($visitor->present ? "Si" : "No"); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Direccion de email']); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Telefono']); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Empresa']); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Cargo']); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Provincia']); ?></td>
          <td><?php echo e($forms[$visitor->form_id]['Localidad']); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/visitor/visitor.blade.php ENDPATH**/ ?>