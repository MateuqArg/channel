<a data-bs-toggle="modal" data-bs-target="#create" class="btn btn-success btn-create" id="create-btn"><i class="bi bi-plus-lg"></i></a>

<div class="modal fade" wire:ignore.self id="create" tabindex="-1" aria-labelledby="createLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createLabel">Dar de alta charla</h5>
        
      </div>
      <div class="modal-body">
          <div class="mb-3">
              <div class="mb-3">
                <label for="title" class="form-label">Titulo</label>
                <br>
                <input type="text" wire:model.defer="cretalk.title" id="title" class="form-control" aria-describedby="titleHelp">
              </div>
              <div class="mb-3" wire:ignore>
                <label for="event" class="form-label">Selecciona el evento relacionado a la charla</label>
                <select class="form-control" wire:model.defer="cretalk.event" id="crevents">
                  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($event->id); ?>"><?php echo e($event->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="mb-3" wire:ignore>
                <label for="exhibitor" class="form-label">Ahora selecciona el usuario que será expositor</label>
                <select class="form-control" wire:model.defer="cretalk.exhibitor" id="crexhibitors">
                  <?php $__currentLoopData = $exhibitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($exhibitor->id); ?>"><?php echo e($exhibitor->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-arrow-left"></i></button>
        <button wire:click="create()" class="btn btn-success"><i class="bi bi-send"></i> ENVIAR</button>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function() {
    $('#crevents').select2({theme: 'bootstrap-5', dropdownParent: $('#create')});
    $('#crexhibitors').select2({theme: 'bootstrap-5', dropdownParent: $('#create')});
    $('#crevents').on('change', function (e) {
        var data = $('#crevents').select2("val");
        window.livewire.find('<?php echo e($_instance->id); ?>').set('cretalk.event', data);
    });
    $('#crexhibitors').on('change', function (e) {
        var data = $('#crexhibitors').select2("val");
        window.livewire.find('<?php echo e($_instance->id); ?>').set('cretalk.exhibitor', data);
    });
  });
</script><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/talk/create.blade.php ENDPATH**/ ?>