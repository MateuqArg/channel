<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/jquery.flexdatalist.min.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('/js/jquery.flexdatalist.min.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-borderless/borderless.css">

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('talks')->html();
} elseif ($_instance->childHasBeenRendered('7FhdebE')) {
    $componentId = $_instance->getRenderedChildComponentId('7FhdebE');
    $componentTag = $_instance->getRenderedChildComponentTagName('7FhdebE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7FhdebE');
} else {
    $response = \Livewire\Livewire::mount('talks');
    $html = $response->html();
    $_instance->logRenderedChild('7FhdebE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/organizer/events/talks.blade.php ENDPATH**/ ?>