<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.exhibitornavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-borderless/borderless.css">

<?php if(!$meetings->isEmpty()): ?>
  <div class="row">
    <a class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#meetings" href="">
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <p class="mb-0"><i class="bi bi-check-circle-fill"></i> Hay reuniones pendientes de aprobación</p>
    </div>
    </a>
  </div>
 <?php endif; ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('exhvisitors')->html();
} elseif ($_instance->childHasBeenRendered('de1Bu5b')) {
    $componentId = $_instance->getRenderedChildComponentId('de1Bu5b');
    $componentTag = $_instance->getRenderedChildComponentTagName('de1Bu5b');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('de1Bu5b');
} else {
    $response = \Livewire\Livewire::mount('exhvisitors');
    $html = $response->html();
    $_instance->logRenderedChild('de1Bu5b', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<div class="modal fade" id="meetings" tabindex="-1" aria-labelledby="meetingsLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="meetingsLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="accordion" id="accordionExample">
          <?php if(Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
              <p class="mb-0"><i class="bi bi-check-circle-fill"></i> <?php echo e(Session::get('success')); ?></p>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
          <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="accordion-item">
            <h2 class="accordion-header">
              <div class="row">
                <div class="col-9">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($meeting->custid); ?>" aria-expanded="true" aria-controls="<?php echo e($meeting->custid); ?>">
                    <?php echo e($forms[$meeting->visitor->form_id]['Nombre completo']); ?> - <?php echo e($meeting->event->title); ?>

                  </button>
                </div>
                <div class="col-1">
                  <a class="btn btn-success" href="<?php echo e(route('exhibitor.meeting.accept', ['id' => $meeting->id])); ?>"><i class="bi bi-check-lg"></i></a>
                </div>
                <div class="col-1 ms-1">
                  <a class="btn btn-danger" href="<?php echo e(route('exhibitor.meeting.reject', ['id' => $meeting->id])); ?>"><i class="bi bi-x-lg"></i></a>
                </div>
              </div>
            </h2>
            <div id="<?php echo e($meeting->custid); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p class="mb-0">
                  <strong>Nombre:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Nombre completo']); ?><br>
                  <strong>Email:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Direccion de email']); ?><br>
                  <strong>Teléfono:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Telefono']); ?><br>
                  <strong>Empresa:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Empresa']); ?><br>
                  <strong>Cargo:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Cargo']); ?><br>
                  <strong>Provincia:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Provincia']); ?><br>
                  <strong>Ciudad:</strong> <?php echo e($forms[$meeting->visitor->form_id]['Localidad']); ?>

                </p>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
	<?php if(Session::has('success')): ?>
	  $(document).ready(function(){
	    $('#meetings').modal('show');
	  });
	<?php endif; ?>
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/exhibitor/visitors.blade.php ENDPATH**/ ?>