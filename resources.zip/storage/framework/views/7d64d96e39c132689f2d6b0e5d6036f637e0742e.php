<div>
  <input type="text" wire:model="charge">
  <a id="delete-btn" wire:click="destroy()"><i class="bi bi-trash btn btn-outline-danger"></i></a>
</div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/delete.blade.php ENDPATH**/ ?>