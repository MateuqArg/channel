<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-borderless/borderless.css">

<script>
    $(document).ready( function() {
        Swal.fire({
            title: '¡Arreglado!',
            html: 'Reunión confirmada correctamente',
            icon: 'success',
            showConfirmButton: false,
            allowOutsideClick: false,
            allowEnterKey: false,
            allowEscapeKey: false,
        })
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/main/meetaccept.blade.php ENDPATH**/ ?>