<div class="container-fluid">
  <div class="row">
    <div class="col d-flex gradient top-table">
      <div>
        <input type="text" wire:model="search" class="form-control" placeholder="Buscar por id o eventos">
      </div>
      <div class="ms-auto">
        <button wire:click="download" class="btn btn-outline-primary download-btn"><i class="bi bi-download"></i> DESCARGAR</button>
      </div>
    </div>
  </div>
  <div class="row g-3">
    <table class="table">
      <thead class="gradient">
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <th scope="col">Acciones</th>
          <?php endif; ?>
          <th scope="col">ID</th>
          <th scope="col">ID público</th>
          <th scope="col">Nombre</th>
          <th scope="col">Fecha</th>
          <th scope="col">¿Aprobar inscripciones?</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <?php if(!\Auth::user()->hasRole('staff')): ?>
          <td>
            <?php echo $__env->make('livewire.event.actions', ['event' => $event], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </td>
          <?php endif; ?>
          <td><?php echo e($event->id); ?></td>
          <td><?php echo e($event->custid); ?></td>
          <td><?php echo e($event->title); ?></td>
          <td><?php echo e($event->date); ?></td>
          <td><?php echo e($event->approve ? "Si" : "No"); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <?php if(!\Auth::user()->hasRole('staff')): ?>
  <?php echo $__env->make('livewire.event.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  
  

  <script>
    window.livewire.on('alert', event => {
      $('#edit<?php echo e($event->id); ?>').modal('hide');
      $('#create').modal('hide');
      Swal.fire({
        title: event.title,
        html: event.text,
        icon: event.type,
        timer: 2000,
      })
    })
  </script>
</div><?php /**PATH C:\xampp\htdocs\channel\resources\views/livewire/event/event.blade.php ENDPATH**/ ?>