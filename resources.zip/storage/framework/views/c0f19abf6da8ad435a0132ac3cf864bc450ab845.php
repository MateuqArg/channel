<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.auth.organizernavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/jquery.flexdatalist.min.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('/js/jquery.flexdatalist.min.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-borderless/borderless.css">

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('exhibitors')->html();
} elseif ($_instance->childHasBeenRendered('nA4L8UT')) {
    $componentId = $_instance->getRenderedChildComponentId('nA4L8UT');
    $componentTag = $_instance->getRenderedChildComponentTagName('nA4L8UT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nA4L8UT');
} else {
    $response = \Livewire\Livewire::mount('exhibitors');
    $html = $response->html();
    $_instance->logRenderedChild('nA4L8UT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\channel\resources\views/organizer/events/exhibitors.blade.php ENDPATH**/ ?>