<?php return array (
  'chats' => 'App\\Http\\Livewire\\Chats',
  'draws' => 'App\\Http\\Livewire\\Draws',
  'events' => 'App\\Http\\Livewire\\Events',
  'exhibitors' => 'App\\Http\\Livewire\\Exhibitors',
  'exhvisitors' => 'App\\Http\\Livewire\\Exhvisitors',
  'profiles' => 'App\\Http\\Livewire\\Profiles',
  'talks' => 'App\\Http\\Livewire\\Talks',
  'visitors' => 'App\\Http\\Livewire\\Visitors',
);